package com.example.calculatorapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView resultTextView;
    private StringBuilder input = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultTextView = findViewById(R.id.resultTextView);

        setupButtonListeners();
    }

    private void setupButtonListeners() {
        // Number buttons
        findViewById(R.id.button_0).setOnClickListener(v -> appendToInput("0"));
        findViewById(R.id.button_1).setOnClickListener(v -> appendToInput("1"));
        findViewById(R.id.button_2).setOnClickListener(v -> appendToInput("2"));
        findViewById(R.id.button_3).setOnClickListener(v -> appendToInput("3"));
        findViewById(R.id.button_4).setOnClickListener(v -> appendToInput("4"));
        findViewById(R.id.button_5).setOnClickListener(v -> appendToInput("5"));
        findViewById(R.id.button_6).setOnClickListener(v -> appendToInput("6"));
        findViewById(R.id.button_7).setOnClickListener(v -> appendToInput("7"));
        findViewById(R.id.button_8).setOnClickListener(v -> appendToInput("8"));
        findViewById(R.id.button_9).setOnClickListener(v -> appendToInput("9"));

        // Operator buttons
        findViewById(R.id.button_add).setOnClickListener(v -> appendToInput("+"));
        findViewById(R.id.button_subtract).setOnClickListener(v -> appendToInput("-"));
        findViewById(R.id.button_multiply).setOnClickListener(v -> appendToInput("*"));
        findViewById(R.id.button_divide).setOnClickListener(v -> appendToInput("/"));

        // Other buttons
        findViewById(R.id.button_clear).setOnClickListener(v -> clearInput());
        findViewById(R.id.button_equals).setOnClickListener(v -> calculateResult());
    }

    private void appendToInput(String value) {
        input.append(value);
        resultTextView.setText(input.toString());
    }

    private void clearInput() {
        input.setLength(0);
        resultTextView.setText("");
    }

    private void calculateResult() {
        try {
            String expression = input.toString();
            // Using a simple eval function (make sure to replace with your own logic)
            double result = eval(expression);
            resultTextView.setText(String.valueOf(result));
            input.setLength(0); // Clear input after calculation
        } catch (Exception e) {
            resultTextView.setText("Error");
        }
    }

    private double eval(String expression) {
        // Basic evaluation logic (you might want to use a library for more complex expressions)
        // This is just a placeholder, implement your calculation logic here
        return 0; // Replace with actual logic
    }
}
